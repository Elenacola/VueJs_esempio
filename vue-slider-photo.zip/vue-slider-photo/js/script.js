const {
        createApp
} = Vue;

createApp({
    data(){
        return{
            activeSlide : 0,
            autoPlay : null,
            slides: [
                {
                    image: 'img/01.webp',
                    title: 'figura 1',
                    text: 'Lorem ipsum xxx.',
                }, 
                {
                    image: 'img/02.webp',
                    title: 'figura 2 ',
                    text: 'Lorem ipsum xxx.',
                }, 
                {
                    image: 'img/03.webp',
                    title: 'Figura 3',
                    text: "Lorem ipsum xxx.",
                }, 
                {
                    image: 'img/04.webp',
                    title: 'Figura 4',
                    text: 'Lorem ipsum xxx.',
                }, 
                {
                    image: 'img/05.webp',
                    title: "Figura 5",
                    text: 'Lorem ipsum xxx5',
                }
            ]
        }
    },
    created(){
        this.autoScroll();
    },
    methods: {
        changeSlide(index){
            this.activeSlide = index;
        },
        next(){
            this.activeSlide++;
            if(this.activeSlide > this.slides.lenght -1){
                this.activeSlide = 0;
            }
        },
        prev(){
            this.activeSlide--;
            if(this.activeSlide > this.slides.lenght -1){
                this.activeSlide = 0;
            }
        },
        autoScroll(){
            this.autoPlay = setInterval(() => {
                this.next();
            }, 3000);
        },
        stopAutoScroll(){
            clearInterval(this.autoPlay)
            this.autoPlay = null;
        }
    },
    
}).mount('#app');
